API Reference
================

.. toctree::
   :maxdepth: 4

   src/bumblebee_status
