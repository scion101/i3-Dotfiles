import pytest

def test_load_module():
    __import__("modules.core.pasource")

